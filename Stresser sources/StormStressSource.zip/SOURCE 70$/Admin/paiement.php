<?php
{
    "product": {
        "title": "Example",
        "price": 50,
        "webhook_urls": [
            "https://webhook-endpoint.shoppy.dev"
        ],
        "gateways": ["Bitcoin", "Ethereum", "PayPal"],
        "confirmations": 1
    }
}
?>