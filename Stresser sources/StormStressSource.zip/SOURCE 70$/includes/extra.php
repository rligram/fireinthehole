<?php
if (!$user-> notBanned($odb))
{
	header('Location: logout.php');
}
if (!$user-> Question($odb))
{
	header('Location: google.php');
}
?>